namespace aaaaa{ 

    public class Registration
    {
        public Component Component { get; set; }
    }

}