using System.Collections.Generic; 
namespace aaaaa{ 

    public class Root
    {
        public List<Registration> Registrations { get; set; }
        public int Version { get; set; }
    }

}