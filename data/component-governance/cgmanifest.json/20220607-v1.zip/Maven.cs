namespace aaaaa{ 

    public class Maven
    {
        public string ArtifactId { get; set; }
        public string GroupId { get; set; }
        public string Version { get; set; }
    }

}