namespace aaaaa{ 

    public class Component
    {
        public string Type { get; set; }
        public Maven Maven { get; set; }
    }

}