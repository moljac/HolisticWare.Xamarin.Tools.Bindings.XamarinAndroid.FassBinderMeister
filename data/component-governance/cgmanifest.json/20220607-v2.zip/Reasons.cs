using Newtonsoft.Json; 
namespace HolisticWare.Xamarin.Tools.NuGet.Client.ServerAPI.Generated{ 

    public class Reasons
    {
        [JsonProperty("@container")]
        public string Container { get; set; }
    }

}