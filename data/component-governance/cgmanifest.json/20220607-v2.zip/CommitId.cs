using Newtonsoft.Json; 
namespace HolisticWare.Xamarin.Tools.NuGet.Client.ServerAPI.Generated{ 

    public class CommitId
    {
        [JsonProperty("@id")]
        public string Id { get; set; }
    }

}