using Newtonsoft.Json; 
namespace HolisticWare.Xamarin.Tools.NuGet.Client.ServerAPI.Generated{ 

    public class PackageContent
    {
        [JsonProperty("@type")]
        public string Type { get; set; }
    }

}