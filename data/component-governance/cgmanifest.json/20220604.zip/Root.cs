    public class Root
    {
        public List<string> versions { get; set; }
    }
