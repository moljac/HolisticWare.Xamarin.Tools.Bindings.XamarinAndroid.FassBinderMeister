# CronetExample
The project is a sample implementation of the recently made available library Cronet.

I have detailly explained about the library and how to perform network requests in the article titled <a href="https://www.gsrikar.com/2018/12/cronet-chromium-network-stack.html">Cronet - Chromium Network Stack for Android</a>.
